
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright">
                <center><p class="mb-0">কপিরাইট <script>document.write(new Date().getFullYear());</script> © {{ $insName }} সমস্ত অধিকার সংরক্ষিত।</p></center>
            </div>

        </div>
    </div>
</footer>


