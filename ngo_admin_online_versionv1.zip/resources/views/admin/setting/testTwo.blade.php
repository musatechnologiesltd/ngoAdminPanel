   <!-- Bootstrap css-->

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<textarea class="form-control summernote" name="pdf_body_one" required id="" type="text" placeholder="আমার প্রোফাইল"
>
আমার প্রোফাইল

</textarea>
<script>

    $(document).ready(function() {
      $('.summernote').summernote();
    });
            </script>
