
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright">
                <center><p class="mb-0">কপিরাইট <script>document.write(new Date().getFullYear());</script> © {{ $ins_name }} সমস্ত অধিকার সংরক্ষিত।</p></center>
            </div>
            {{-- <div class="col-md-6">
                <p class="pull-right mb-0">Hand crafted & made with Musa Tech<i class="fa fa-heart font-secondary"></i>
                </p>
            </div> --}}
        </div>
    </div>
</footer>


