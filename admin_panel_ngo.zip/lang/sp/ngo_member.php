<?php
return [
    'ngo_member_list'=>'NGO General Members List',
    'ngo_member'=>'NGO General Member',
    'ngo_member_registration'=>'NGO General Member Registration',
    'name'=>'Name',
    'designation'=>'Designation',
    'date_of_birth'=>'Date of Birth',
    'nid_no'=>'NID No',
    'mobile_no'=>'Mobile No',
    'fathers_name'=>'Fathers Name',
    'present_address'=>'Present Address',
    'permanent_address'=>'Permanent Address',
    'name_of_spouse'=>'Name of Spouse',
    'remarks'=>'Remarks',
];

?>
