<?php
return [
    'newscategory'=>'News Category',
     'newslist'=>'News List',
     'add'=>'Add',
     'newscategory'=>'Category name',
     'webvisible'=>'Website Visible',
     'addnew'=>'Add News Category',
     'yes'=>'Yes',
     'no'=>'No',
     'update'=>'Update',
     'UpdateCategoryNewsName'=>'Update News Category Name',


     'repotername'=>'Repoter Name',
     'repoterlist'=>'Repoter List',
     'newsrepoterlist'=>'News Repoter List',
     'newsrepoterdetail'=>'Repoter Detail',
     'profileimage'=>'Profile Image',
     'webvisible'=>'Website Visible',
     'addnew2'=>'Add New Repoter',
     'updaterepotername'=>'Update Repoter Name',



     'title'=>'Title',
     'newsmlist'=>'News List',
     'news'=>'News',
     'photo'=>'News Main Image',
     'newsdetail'=>'News Description',
     'addnews'=>'Add New News',
    'updatenewsname'=>'Update News',


    'addnewevent'=>'Add New Event',
     'eventdate'=>'Event Date',
     'eventtime'=>'Event Time',
     'totalseat'=>'Total Seat',
     'eventmail'=>'Event Email',
     'eventcontact'=>'Event Contact',
     'eventplace'=>'Event Place',
     'guestphoto'=>'Guest Photo',
     'guestname'=>'Guest Name',
     'guestdesi'=>'Guest Designation',

     'updateevent'=>'Update Event Information',

     'eventlist'=>'Event List',
     'event'=>'Event',
      'and'=>'And',

'guestlist'=>'Guest List',

'updateguestlist'=>'Update Guest List',

'close'=>'Close',



		];

?>