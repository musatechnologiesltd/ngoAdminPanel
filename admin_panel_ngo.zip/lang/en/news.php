<?php
return [

 
  'newscategory'=>'সংবাদ বিভাগ',
     'newslist'=>'সংবাদ বিভাগের তালিকা',
     'add'=>'যোগ করুন',
     'newscategory'=>'বিভাগের নাম',
     'webvisible'=>'ওয়েবসাইটে দেখান ',
     'addnew'=>'নতুন বিভাগের নাম যুক্ত করুন ',
     'yes'=>'হ্যাঁ',
     'no'=>'না',
     'update'=>'আপডেট করুন',
     'UpdateCategoryNewsName'=>'বিভাগের নাম আপডেট করুন ',


     'repotername'=>'প্রতিবেদকের নাম',
     'repoterlist'=>'প্রতিবেদকের তালিকা',
     'newsrepoterlist'=>'সংবাদ প্রতিবেদক এর তালিকা ',
     'newsrepoterdetail'=>'প্রতিবেদক এর বিবরন ',
     'profileimage'=>'প্রোফাইল ছবি',
     'addnew2'=>'নতুন প্রতিবেদকের নাম যুক্ত করুন',
     'updaterepotername'=>'প্রতিবেদকের নাম আপডেট করুন ',




       'title'=>'শিরোনাম',
     'newsmlist'=>'সংবাদ তালিকা',
     'news'=>'সংবাদ ',
     'photo'=>'ছবি',
     'newsdetail'=>'বিবরন',
     
     'addnews'=>'নতুন সংবাদ যুক্ত করুন',
    
     'updatenewsname'=>'সংবাদ আপডেট করুন ',


     'addnewevent'=>'নতুন ইভেন্ট যুক্ত করুন',
     'eventdate'=>'ইভেন্টের তারিখ ',
     'eventtime'=>'ইভেন্টের সময় ',
     'totalseat'=>'মোট আসন',
     'eventmail'=>'যোগাযোগ ইমেল',
     'eventcontact'=>'যোগাযোগ নম্বর',
     'eventplace'=>'ইভেন্টের স্থান ',
     'guestphoto'=>'অথিতির ছবি',
     'guestname'=>'অথিতির নাম',
     'guestdesi'=>'অথিতির উপাধি',

     'updateevent'=>'ইভেন্ট আপডেট করুন',

     'eventlist'=>'ইভেন্ট তালিকা',
     'event'=>'ইভেন্ট',
     'and'=>'এবং',

     'guestlist'=>'অতিথির তালিকা ',
     'updateguestlist'=>'অতিথি তালিকা আপডেট করুন',
     'close'=>'বন্ধ করুন ',

		];

?>