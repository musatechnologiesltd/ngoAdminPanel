<?php
return [


	'wardlist'=>'ওয়ার্ডের তালিকা',
	'addnewward'=>'নতুন ওয়ার্ড যুক্ত করুন',
	'caname'=>'কাউন্সিলর এবং এডমিন  নাম',
    'cityName'=>'সিটি কর্পোরেশন নাম',
    'address'=>'ঠিকানা',
    'newward'=>'নতুন ওয়ার্ড রেজিস্ট্রেশন ফর্ম',
    'wardinfoenglish'=>'ওয়ার্ড সম্পর্কিত তথ্য (ইংরেজি)',
    'wardinfobangla'=>'ওয়ার্ড সম্পর্কিত তথ্য (বাংলা)',
    'payinformation'=>'পেমেন্ট তথ্য',
    'monthlyprice'=>'মাসিক মূল্য',
    'bcash'=>'বিকাশ',
    'nogod'=>'নগদ ',
    'subtype'=>'সাবস্ক্রিপশন প্রকার',
    'PaymentMethod'=>'মূল্যপরিশোধ পদ্ধতি',
    'Handcash'=>'হ্যান্ড ক্যাশ',
    'paymentgateway'=>'পেমেন্ট গেটওয়ে',
    'ward'=>'ওয়ার্ড',
    'ContactInformation'=>'যোগাযোগের তথ্য',
    'Email'=>'ইমেল',
    'Phone'=>'ফোন নম্বর',
    'office'=>'কার্যালয়',
    'District'=>'জেলা',
    'postoffice'=>'ডাক ঘর',
    'postcode'=>'পোস্ট কোড ',
    'bimageLa'=>'বর্ডার ইমেজ(ল্যান্ডস্ক্যাপ)',
    'bimageLo'=>'বর্ডার ইমেজ(লম্বা)',
    'Logo'=>'লোগো',
    'pollice'=>'থানা',
     'annual'=>'বার্ষিক',
    'quater'=>'ত্রৈমাসিক',
    'month'=>'মাসিক',
   'wardcounsilinfo'=>'ওয়ার্ড কাউন্সিল তথ্য',
   'upd'=>'ওয়ার্ড রেজিস্ট্রেশন ফর্ম আপডেট করুন',
   'uw'=>'আপডেট ওয়ার্ড',
   'phis'=>'পেমেন্ট হিস্টোরি ',
   'renew'=>'নবায়ন করুন',
   'month'=>'মাস',
   'payble'=>'প্রদেয় পরিমান',
   'paymentamount'=>'পরিশোধিত অর্থ',
   'due'=>'বাকি',
   'wardadminlist'=>'ওয়ার্ড প্রশাসক তালিকা',
   'wardcounsilorlist'=>'ওয়ার্ড কাউন্সিলর তালিকা', 
   'addnewwardadmin'=>'নতুন ওয়ার্ড প্রশাসক যুক্ত করুন',
   'addnewwardcounsilor'=>'নতুন ওয়ার্ড কাউন্সিলর যুক্ত করুন',
   'confirmpassword'=>'পাসওয়ার্ড নিশ্চিত করুন',
   'assignrolls'=>'রোল বরাদ্দ করুন',
   'profileimage'=>'প্রোফাইল ছবি',
   'wardadmininformation'=>'ওয়ার্ড প্রশাসক তথ্য',
   'wardcounsilorinformation'=>'ওয়ার্ড কাউন্সিলর তথ্য',
   'wardadmin'=>'ওয়ার্ড প্রশাসক ',
   'wardcounsilor'=>'ওয়ার্ড কাউন্সিলর ',
   'WardInformation'=>'ওয়ার্ড সম্পর্কিত তথ্য',
   'role'=>'রোল',



   'UpdateWardAdmin'=>'ওয়ার্ড প্রশাসক আপডেট করুন',
   'updatewardCounsilor'=>'ওয়ার্ড কাউন্সিলর আপডেট করুন',
   'userbangla'=>'নাম(বাংলা)',




];

?>