<?php
return [
    'home'=>'হোম',
];


?>
