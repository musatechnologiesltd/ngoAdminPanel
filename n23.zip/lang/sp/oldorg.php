<?php
return [

    'telephone'=>'Telephone Number',
    'mobilenumber'=>'Mobile Number',
    'email'=>'Email',
    'website'=>'Website',
    'ceo'=>'Chief executive information',
    'digiSign'=>'Digital Signature',
    'digiSeal'=>'Digital Seal'


];

?>
