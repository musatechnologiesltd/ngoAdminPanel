<?php
return [

    'old'=>'Old',
    'new'=>'New',
    'ngo_type'=>'Type of NGO',
    'reg_number'=>'Registration Number',
    'last_renew_date'=>'Date of last registration/renewal',
    'in1'=>'This field is required',
    'reg1'=>'Registration',
    'sm'=>'Must be use valid email for varification',
    'reg'=>'Register',
    'step'=>'Step 01',
    'tt_one'=>' Registration for NGO',
    'person_name'=>'NGO Name',
    'phone_number'=>'Mobile Number',


    'office'=>'NGO Affairs Bureau',
    'office1'=>'NGO Online Registration Portal, v1.0.0. All Rights Reserved.',
    'home'=>'Home',
    'apply_online'=>'Apply Online',
    'renew_application'=>'Renew Application',
    'name_change' =>'Name Change',
    'instruction'=>'Instruction',
    'registration_fee'=>'Registration Fee',
    'sign_in' => 'Sign In',
    'Registration_Here'=>'Registration Here',
    'Log_in'=>'Log In',
    'bangla'=>'Bangla',
  'passwordc'=>'Confirm Password',
    'english'=>'English',
    'email'=>'Email',
    'password'=>'Password',
    'Forgot_Password'=>'Forgot Password',
    'check_status'=>'Check Status',
    'ngo_ab'=>'NGOAB',

    'log_in_title'=>'Welcome Back to Our <strong>NGO Affairs Bureaus</strong> Digital Platform',
];


?>
