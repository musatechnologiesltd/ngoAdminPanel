<?php
return [
    '10y'=>'বিগত ১০(দশ) বছরে বৈদেশিক অনুদানে পরিচালত কার্যক্রমের বিবরণ (প্রকল্প ওয়ারী তথাদির সংক্ষিপ্তসার সংযুক্ত করতে হবে)',
    'money'=>'অঙ্গীকারকৃত অনুদানের পরিমাণ (বৈদেশিক মুদ্রা/বাংলাদেশ টাকায়)',
    'copy'=>'দাতা/দাতাসংস্থার অঙ্গীকারপত্রের কপি',
    'dd'=>'দাতা/দাতা সংস্থাসমূহের নাম ও ঠিকানা',
    'pp'=>'প্রকল্প এলাকা (জেলা ও উপজেলা)',
    'des'=>'বিস্তারিত বিবরণ সংযুক্ত করতে হবে',
    'Add_New_Donor_Information'=>'নতুন দাতার তথ্য যোগ করুন',
    'Field_of_proposed_activities'=>'প্রস্তাবিত কার্যক্রমের ক্ষেত্র',
    'Step_2'=>'ধাপ ০২',
    'Plan_of_Operation' => 'পরিচালন পরিকল্পনা',
    'Project_District' => 'প্রকল্প জেলা',
    'Project_Sub_District' => 'উপজেলা',
    'Source_of_Fund' => 'তহবিলের উৎস',
    'Name_of_donor_organization' => 'দাতা সংস্থার নাম',
    'Address_of_donor_organization' => 'দাতা সংস্থার ঠিকানা',
    'Letter_of_Commitment_from_Prospective_donor' => 'সম্ভাব্য দাতার কাছ থেকে প্রতিশ্রুতির চিঠি',
    'What_is_Your_Expected_Annual_Budget_Foreign_Currency_or_Bangladeshi_Taka' => 'অঙ্গিকারকৃত অনুদানের পরিমাণ(বৈদেশিক মুদ্রা/বাংলাদেশ টাকা)',
    ];


?>
